import { Stethoscope, Activity, Syringe, Heart } from 'lucide-react';

export const services = [
  {
    title: 'General Dentistry',
    description: 'Comprehensive dental check-ups, cleanings, and preventive care',
    icon: Stethoscope
  },
  {
    title: 'Root Canal Treatment',
    description: 'Expert endodontic procedures with minimal discomfort',
    icon: Activity
  },
  {
    title: 'Dental Implants',
    description: 'Permanent solutions for missing teeth',
    icon: Syringe
  },
  {
    title: 'Cosmetic Dentistry',
    description: 'Transform your smile with our cosmetic dental procedures',
    icon: Heart
  }
];