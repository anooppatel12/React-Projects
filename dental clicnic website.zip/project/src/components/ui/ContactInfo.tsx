import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ContactInfoProps {
  icon: LucideIcon;
  text: string;
}

export default function ContactInfo({ icon: Icon, text }: ContactInfoProps) {
  return (
    <div className="flex items-center space-x-4">
      <Icon className="h-6 w-6 text-blue-600" />
      <span className="text-gray-700">{text}</span>
    </div>
  );
}