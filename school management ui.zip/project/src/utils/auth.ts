import { LoginCredentials, User } from '../types/auth';
import { students, teachers } from '../data/mockData';

// Mock user data for demonstration
const mockUsers: User[] = [
  {
    id: 'admin1',
    email: 'admin@school.com',
    name: 'Admin User',
    role: 'admin',
    password: 'password', // In real app, this would be hashed
  },
  ...teachers.map(teacher => ({
    id: teacher.id,
    email: teacher.email,
    name: teacher.name,
    role: 'teacher' as const,
    password: teacher.password,
  })),
  ...students.map(student => ({
    id: student.id,
    email: student.email,
    name: student.name,
    role: 'student' as const,
    password: student.password,
  })),
];

export const mockLogin = async (credentials: LoginCredentials): Promise<User> => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));

  const user = mockUsers.find(u => u.email === credentials.email);
  
  if (user && credentials.password === user.password) {
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }
  
  throw new Error('Invalid credentials');
};