import React, { useState } from 'react';
import { courses, teachers, students } from '../data/mockData';
import { BookOpen, Users, GraduationCap } from 'lucide-react';
import AddCourseForm from './forms/AddCourseForm';

const CourseList = () => {
  const [courseList, setCourseList] = useState(courses);
  const [showAddForm, setShowAddForm] = useState(false);

  const getTeacherName = (teacherId: string) => {
    const teacher = teachers.find((t) => t.id === teacherId);
    return teacher ? teacher.name : 'Unknown Teacher';
  };

  const getEnrolledStudents = (studentIds: string[]) => {
    return students.filter((student) => studentIds.includes(student.id));
  };

  const handleAddCourse = (newCourse: any) => {
    setCourseList([...courseList, newCourse]);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Courses</h2>
        <button 
          onClick={() => setShowAddForm(true)}
          className="bg-purple-500 text-white px-4 py-2 rounded-lg hover:bg-purple-600"
        >
          Add Course
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courseList.map((course) => {
          const enrolledStudents = getEnrolledStudents(course.students);
          return (
            <div key={course.id} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                <div className="bg-purple-100 p-2 rounded-full">
                  <BookOpen className="w-5 h-5 text-purple-600" />
                </div>
                <div className="ml-3">
                  <h3 className="font-semibold">{course.name}</h3>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center">
                  <GraduationCap className="w-4 h-4 mr-2 text-gray-400" />
                  <span className="text-sm">{getTeacherName(course.teacher)}</span>
                </div>

                <div>
                  <div className="flex items-center mb-2">
                    <Users className="w-4 h-4 mr-2 text-gray-400" />
                    <span className="text-sm">Enrolled Students ({enrolledStudents.length})</span>
                  </div>
                  <div className="space-y-2">
                    {enrolledStudents.map((student) => (
                      <div key={student.id} className="text-sm text-gray-600 ml-6">
                        • {student.name}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showAddForm && (
        <AddCourseForm
          onClose={() => setShowAddForm(false)}
          onSubmit={handleAddCourse}
        />
      )}
    </div>
  );
};

export default CourseList;