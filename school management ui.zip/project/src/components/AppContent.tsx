import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import LoginForm from './auth/LoginForm';
import Sidebar from './Sidebar';
import Header from './layout/Header';
import Dashboard from './Dashboard';
import StudentList from './StudentList';
import TeacherList from './TeacherList';
import CourseList from './CourseList';

const AppContent = () => {
  const { isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = React.useState('dashboard');

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'students':
        return <StudentList />;
      case 'teachers':
        return <TeacherList />;
      case 'courses':
        return <CourseList />;
      case 'settings':
        return <div className="p-6">Settings page coming soon...</div>;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="flex-1 ml-64">
        <Header />
        {renderContent()}
      </div>
    </div>
  );
};

export default AppContent;