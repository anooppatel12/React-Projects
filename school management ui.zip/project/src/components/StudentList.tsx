import React, { useState } from 'react';
import { User, Mail, TrendingUp, Clock } from 'lucide-react';
import { students as initialStudents } from '../data/mockData';
import AddStudentForm from './forms/AddStudentForm';

const StudentList = () => {
  const [students, setStudents] = useState(initialStudents);
  const [showAddForm, setShowAddForm] = useState(false);

  const handleAddStudent = (newStudent: any) => {
    setStudents([...students, newStudent]);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Students</h2>
        <button 
          onClick={() => setShowAddForm(true)}
          className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
        >
          Add Student
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-6">
          {students.map((student) => (
            <div
              key={student.id}
              className="bg-gray-50 rounded-lg p-4 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center mb-4">
                <div className="bg-blue-100 p-2 rounded-full">
                  <User className="w-5 h-5 text-blue-600" />
                </div>
                <div className="ml-3">
                  <h3 className="font-semibold">{student.name}</h3>
                  <p className="text-sm text-gray-500">{student.grade}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center text-sm">
                  <Mail className="w-4 h-4 mr-2 text-gray-400" />
                  <span>{student.email}</span>
                </div>
                <div className="flex items-center text-sm">
                  <TrendingUp className="w-4 h-4 mr-2 text-gray-400" />
                  <span>Performance: {student.performance}%</span>
                </div>
                <div className="flex items-center text-sm">
                  <Clock className="w-4 h-4 mr-2 text-gray-400" />
                  <span>Attendance: {student.attendance}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showAddForm && (
        <AddStudentForm
          onClose={() => setShowAddForm(false)}
          onSubmit={handleAddStudent}
        />
      )}
    </div>
  );
};

export default StudentList;