import React, { useState } from 'react';
import { User, Mail, BookOpen } from 'lucide-react';
import { teachers as initialTeachers } from '../data/mockData';
import AddTeacherForm from './forms/AddTeacherForm';

const TeacherList = () => {
  const [teachers, setTeachers] = useState(initialTeachers);
  const [showAddForm, setShowAddForm] = useState(false);

  const handleAddTeacher = (newTeacher: any) => {
    setTeachers([...teachers, newTeacher]);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Teachers</h2>
        <button 
          onClick={() => setShowAddForm(true)}
          className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600"
        >
          Add Teacher
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
          {teachers.map((teacher) => (
            <div
              key={teacher.id}
              className="bg-gray-50 rounded-lg p-4 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center mb-4">
                <div className="bg-green-100 p-2 rounded-full">
                  <User className="w-5 h-5 text-green-600" />
                </div>
                <div className="ml-3">
                  <h3 className="font-semibold">{teacher.name}</h3>
                  <p className="text-sm text-gray-500">{teacher.subject}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center text-sm">
                  <Mail className="w-4 h-4 mr-2 text-gray-400" />
                  <span>{teacher.email}</span>
                </div>
                <div className="flex items-center text-sm">
                  <BookOpen className="w-4 h-4 mr-2 text-gray-400" />
                  <span>{teacher.subject} Specialist</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showAddForm && (
        <AddTeacherForm
          onClose={() => setShowAddForm(false)}
          onSubmit={handleAddTeacher}
        />
      )}
    </div>
  );
};

export default TeacherList;