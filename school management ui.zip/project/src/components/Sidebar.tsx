import React from 'react';
import { BookOpen, Users, GraduationCap, Calendar, Settings } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { icon: BookOpen, label: 'Dashboard', value: 'dashboard' },
    { icon: Users, label: 'Students', value: 'students' },
    { icon: GraduationCap, label: 'Teachers', value: 'teachers' },
    { icon: Calendar, label: 'Courses', value: 'courses' },
    { icon: Settings, label: 'Settings', value: 'settings' },
  ];

  return (
    <div className="bg-white h-screen w-64 fixed left-0 top-0 shadow-lg">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-blue-600">EduManager</h1>
      </div>
      <nav className="mt-8">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.value}
              onClick={() => setActiveTab(item.value)}
              className={`w-full flex items-center p-4 hover:bg-blue-50 transition-colors ${
                activeTab === item.value ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
              }`}
            >
              <Icon className="w-5 h-5 mr-3" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default Sidebar;