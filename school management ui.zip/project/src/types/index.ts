export interface Student {
  id: string;
  name: string;
  grade: string;
  email: string;
  password: string;
  attendance: number;
  performance: number;
}

export interface Teacher {
  id: string;
  name: string;
  subject: string;
  email: string;
  password: string;
}

export interface Course {
  id: string;
  name: string;
  teacher: string;
  students: string[];
}