import { Student, Teacher, Course } from '../types';

export const students: Student[] = [
  {
    id: '1',
    name: 'John Doe',
    grade: '10th',
    email: 'john@school.com',
    password: 'student123', // In real app, this would be hashed
    attendance: 92,
    performance: 85,
  },
  {
    id: '2',
    name: 'Jane Smith',
    grade: '11th',
    email: 'jane@school.com',
    password: 'student123',
    attendance: 95,
    performance: 90,
  },
];

export const teachers: Teacher[] = [
  {
    id: '1',
    name: 'Dr. Sarah Wilson',
    subject: 'Mathematics',
    email: 'sarah@school.com',
    password: 'teacher123',
  },
  {
    id: '2',
    name: 'Prof. Michael Brown',
    subject: 'Science',
    email: 'michael@school.com',
    password: 'teacher123',
  },
];

export const courses: Course[] = [
  {
    id: '1',
    name: 'Advanced Mathematics',
    teacher: '1',
    students: ['1', '2'],
  },
  {
    id: '2',
    name: 'Physics',
    teacher: '2',
    students: ['1'],
  },
];